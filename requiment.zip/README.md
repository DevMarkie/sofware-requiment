# Tài liệu dự án

- Biên bản họp phân công công việc: `docs/bien-ban-hop-phan-cong-cong-viec.md`
- Quy trình xây dựng chức năng: `docs/quy-trinh-xay-dung-chuc-nang.md`

## Cách chạy nhanh (Windows PowerShell)

```powershell
# 1) Chạy server backend (nếu dùng)
cd server
npm install
npm run start

# 2) Mở frontend
cd ..
# Mở file index.html trực tiếp trong trình duyệt hoặc dùng Live Server của VS Code
```

Góp ý/issue: tạo issue trong repo hoặc cập nhật tại biên bản họp.
#   s o f w a r e - r e q u i m e n t  
 